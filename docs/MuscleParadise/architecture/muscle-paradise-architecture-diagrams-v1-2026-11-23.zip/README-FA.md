# بستهٔ نمودارهای معماری Muscle Paradise

این ZIP شامل نقشه‌ها و سورس‌های معماری است: ۳۴ خروجی تصویری PNG/SVG، یازده سورس DOT، دو سند توضیحی و دو فایل راهنما/فهرست؛ در مجموع ۴۹ ورودی.

## فلوچارت جدید: مقصد PWA و دسترسی‌ها

- `docs/MuscleParadise/architecture/muscle-paradise-final-pwa-access-flow-v1-2026-11-23.png`
- `docs/MuscleParadise/architecture/muscle-paradise-final-pwa-access-flow-v1-2026-11-23.svg`
- `docs/MuscleParadise/architecture/muscle-paradise-final-pwa-access-flow-v1-2026-11-23.dot`
- `docs/MuscleParadise/architecture/muscle-paradise-final-pwa-access-flow-v1-2026-11-23.md`

این نمودار تصمیم فعلی مالک را ثبت می‌کند: PWA مشترک برای عضو و کارکنان؛ سه نقش `super_admin`, `admin`, `member`؛ اعطا و لغو مجوزها فقط توسط مالک؛ و نگه‌داشتن فایل‌های Android برای آینده. `coach`, `reception` و `manager` در صورت نیاز کارکرد/الگوی مجوزند، نه نقش امنیتی و نه مجوز ضمنی. **این طرح مقصد است و هنوز در کد پیاده نشده است.** Online-first برای فاز اول فقط پیشنهاد است؛ دامنهٔ آفلاین نهایی نشده.

## معماری هدف و شکاف‌های زیرساخت

- `docs/MuscleParadise/architecture/muscle-paradise-world-class-target-architecture-v1-2026-11-23.png`
- `docs/MuscleParadise/architecture/muscle-paradise-world-class-target-architecture-v1-2026-11-23.svg`
- `docs/MuscleParadise/architecture/muscle-paradise-world-class-target-architecture-v1-2026-11-23.dot`
- `docs/MuscleParadise/architecture/muscle-paradise-world-class-target-architecture-v1-2026-11-23.md`

این سند وضعیت موجود را از هدف پیشنهادی جدا می‌کند و gapهای deployment، بازیابی، زنجیرهٔ تأمین، container hardening و مشاهده‌پذیری را اولویت‌بندی می‌کند. PostgreSQL، OpenTofu، SOPS، OpenTelemetry و سرویس‌های اختیاری فقط با معیار تصمیم روشن پیشنهاد شده‌اند؛ نمودار ادعای پیاده‌سازی یا production audit نیست.

## فلوچارت یکپارچهٔ برنامه، v2

- `docs/MuscleParadise/architecture/muscle-paradise-combined-flow-v2-2026-11-23.png`
- `docs/MuscleParadise/architecture/muscle-paradise-combined-flow-v2-2026-11-23.svg`
- `docs/MuscleParadise/architecture/muscle-paradise-combined-flow-v2-2026-11-23.dot`

این نمودار مسیرهای جاری عضو/کادر و تراکنش‌ها را با چرخهٔ پیشنهادی برنامهٔ تمرین، منبع‌ها، PDF/QR و بازخورد کنار هم می‌گذارد. آن را با فلوچارت جدید PWA/دسترسی اشتباه نگیرید: فلوچارت v2 نمای جریان‌های دامنه است؛ فلوچارت جدید تصمیم محصول و مجوز را مشخص می‌کند.

## راهنمای خواندن

- آبی: وضعیت/مسیر فعلیِ مشاهده‌شده در کد؛ به‌معنی استقرار production نیست.
- فیروزه‌ای: مسیر یا عملیاتِ آزموده‌شده در محیط توسعه؛ نه اثبات E2E یا production.
- کهربایی و خط‌چین: طرح مقصد، پیشنهاد یا نیازمند تصمیم/اثبات بیشتر.
- قرمز: رد دسترسی، شکاف یا توقف fail-closed.
- برای بزرگ‌نمایی از SVG استفاده کنید؛ DOT سورس قابل‌بازتولید نمودار است.
- وجود نمودار یا سورس در ZIP به‌تنهایی پیاده‌سازی، آزمون دستگاه واقعی یا آمادگی انتشار را اثبات نمی‌کند.

`MANIFEST.txt` فهرست کامل فایل‌های تصویری و سورس‌های DOT را دارد.
